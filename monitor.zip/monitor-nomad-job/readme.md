# Monitor Nomad job

## **NOTE**: Always cd to right folder
# Monitor Nomad job

## Update Job

### Update Promstack

**Prometheus**

```bash
# Mercury
consul kv put config/promstack/prometheus/dbaas-instances/node-exporter.json "`cat config/promstack/prometheus/dbaas-instances/node-exporter.json`"
consul kv put config/promstack/prometheus/dbaas-instances/mariadb-exporter.json "`cat config/promstack/prometheus/dbaas-instances/mariadb-exporter.json`"
consul kv put config/promstack/prometheus/dbaas-instances/mysql-exporter.json "`cat config/promstack/prometheus/dbaas-instances/mysql-exporter.json`"
consul kv put config/promstack/prometheus/dbaas-instances/postgresql-exporter.json "`cat config/promstack/prometheus/dbaas-instances/postgresql-exporter.json`"

consul kv put config/promstack/prometheus/prometheus.yaml "`cat config/promstack/prometheus/prometheus.yaml`"
consul kv put config/promstack/prometheus/alert.rules "`cat config/promstack/prometheus/alert.rules`"

nomad job run job/promstack/prometheus.hcl
```

### Update haproxy

```bash
consul kv put config/haproxy/haproxy.cfg "`cat config/haproxy/haproxy.cfg`"

nomad job run job/haproxy/haproxy.hcl
```

### Update Tickstack

**Telegraf DBaaS**

```bash
consul kv put config/tickstack/telegraf-dbaas.conf "`cat config/tickstack/telegraf-dbaas.conf`"

nomad job run job/tickstack/telegraf-dbaas.hcl
```
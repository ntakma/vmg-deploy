# Resource Coordinator Hub

## Update Job

### Update Promstack

**Alertmanager**

```bash
consul kv put config/promstack/alertmanager/templates/telegram.tmpl "`cat config/promstack/alertmanager/templates/telegram.tmpl`"
consul kv put config/promstack/alertmanager/alertmanager.yaml "`cat config/promstack/alertmanager/alertmanager.yaml`"

nomad job run job/promstack/alertmanager.hcl
```

**Prometheus**

```bash
consul kv put config/promstack/prometheus/prometheus.yaml "`cat config/promstack/prometheus/prometheus.yaml`"
consul kv put config/promstack/prometheus/alert.rules "`cat config/promstack/prometheus/alert.rules`"

nomad job run job/promstack/prometheus.hcl
```

**Grafana**

```bash
consul kv put config/promstack/grafana/grafana.ini "`cat config/promstack/grafana/grafana.ini`"
consul kv put config/promstack/grafana/ldap.toml "`cat config/promstack/grafana/ldap.toml`"

nomad job run job/promstack/grafana.hcl
```

### Update network

```bash
# consul kv put config/network-monitor/GeoLite2-Country.mmdb "`cat config/tickstack/telegraf.conf`"

nomad job run job/network-monitor/mars-sflow.hcl
```

### Update haproxy telegraf_proxy

```bash
consul kv put config/haproxy/haproxy-telegraf-proxy/haproxy.cfg "`cat config/haproxy/haproxy-telegraf-proxy/haproxy.cfg`"

nomad job run job/haproxy/haproxy_telegraf_proxy.hcl
```

### Update haproxy

```bash
nomad job run job/haproxy/haproxy.hcl
```

### Update tickstack

**Telegraf**

```bash
consul kv put config/tickstack/telegraf-proxy.conf "`cat config/tickstack/telegraf-proxy.conf`"

nomad job run job/tickstack/telegraf_proxy.hcl
```

**Kapacitor**

```bash
consul kv put config/tickstack/kapacitor.conf "`cat config/tickstack/kapacitor.conf`"

nomad job run job/tickstack/tickstack.hcl
```

**Chronograf**

```bash
nomad job run job/tickstack/chronograf.hcl
```

**Influxdb**

```bash
consul kv put config/tickstack/influxdb.conf "`cat config/tickstack/influxdb.conf`"

nomad job run job/tickstack/tickstack.hcl
```

### Kafka-ui

```bash
nomad job run job/mgmt-services/kafka-ui.hcl
```
